import { TodoService } from './todo-service';
import { TodoApi } from './todo-api';
import { Todo } from './types';

export class ToDoManager {
  private service = new TodoService(new TodoApi());

  async init(): Promise<void> {
    this.service.create('title1', 'desc1');
    this.service.create('title2', 'desc2');
    this.service.create('title3', 'desc3');
    this.service.create('title4', 'desc4');
    this.service.create('title5', 'desc5');
    this.service.create('title6', 'desc6');

  }

  async add(title: string, description = ''): Promise<void> {
    this.service.create(title, description);
  }

  async complete(id: number): Promise<void> {
      
  }

  async list(): Promise<Todo[]> {
    return this.service.
  }
}
